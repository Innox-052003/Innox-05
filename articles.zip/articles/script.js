document.addEventListener("DOMContentLoaded", () => {
  const yearSpan = document.getElementById("year");
  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }

  const forms = document.querySelectorAll(".comment-form");

  forms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();

      const articleId = form.getAttribute("data-comment-form");
      const list = document.querySelector(
        `.comments-list[data-comments-list="${articleId}"]`
      );

      const nameInput = form.querySelector("input[name='name']");
      const commentInput = form.querySelector("textarea[name='comment']");

      const name = nameInput.value.trim();
      const comment = commentInput.value.trim();

      if (!name || !comment || !list) return;

      const li = document.createElement("li");
      li.className = "comment-item";

      const header = document.createElement("div");
      header.className = "comment-header";

      const authorSpan = document.createElement("span");
      authorSpan.className = "comment-author";
      authorSpan.textContent = name;

      const dateSpan = document.createElement("span");
      dateSpan.className = "comment-date";
      const now = new Date();
      dateSpan.textContent = now.toLocaleDateString("fr-FR", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
      });

      header.appendChild(authorSpan);
      header.appendChild(dateSpan);

      const textP = document.createElement("p");
      textP.className = "comment-text";
      textP.textContent = comment;

      li.appendChild(header);
      li.appendChild(textP);

      list.appendChild(li);

      nameInput.value = "";
      commentInput.value = "";
    });
  });
});
